<?php
/**
 * Template part for displaying download section.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 */

?>

<?php /* New feature for update */ ?>

<div class="downloadCV" id="downcv">
        <div class="container">
          <h2>Download Resume</h2>
          <p>Save a PDF version of my resume</p>
          <button class="button" to="assets/Resume Sarah WP.pdf">

          <?php echo do_shortcode('[quick_download_button url="http://localhost/wordpress/wp-content/uploads/2022/11/resume.pdf"]');?>
              <i class="fa-solid fa-arrow-down"></i>
        </button>
        </div>
</div>